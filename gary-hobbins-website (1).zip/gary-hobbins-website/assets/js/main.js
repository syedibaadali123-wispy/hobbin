/* Gary J. Hobbins — site scripts (no dependencies) */
(function () {
  "use strict";

  var doc = document.documentElement;
  doc.classList.remove("no-js");

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Header state on scroll ---------- */
  var header = document.querySelector(".site-header");
  function onScroll() {
    if (header) header.classList.toggle("is-scrolled", window.scrollY > 40);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  if (toggle) {
    toggle.addEventListener("click", function () {
      var open = document.body.classList.toggle("nav-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });
    document.querySelectorAll(".nav-links a").forEach(function (a) {
      a.addEventListener("click", function () {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && document.body.classList.contains("nav-open")) {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  /* ---------- Reveal on scroll ---------- */
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("is-in"); });
  }

  /* ---------- Hero trailer controls ---------- */
  var hero = document.querySelector(".hero");
  var video = document.getElementById("heroVideo");
  if (hero && video) {
    var btnSound = document.getElementById("vcSound");
    var btnPlay = document.getElementById("vcPlay");
    var btnWatch = document.querySelectorAll("[data-watch-trailer]");
    var bar = document.querySelector(".vc-progress i");

    var icons = {
      muted: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M23 9l-6 6M17 9l6 6"/></svg>',
      sound: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 010 7M19 5a10 10 0 010 14"/></svg>',
      pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>',
      play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4l13 8-13 8z"/></svg>'
    };

    function syncUI() {
      if (btnSound) {
        btnSound.innerHTML = (video.muted ? icons.muted : icons.sound) +
          "<span>" + (video.muted ? "Sound off" : "Sound on") + "</span>";
        btnSound.setAttribute("aria-pressed", video.muted ? "false" : "true");
      }
      if (btnPlay) {
        btnPlay.innerHTML = video.paused ? icons.play : icons.pause;
        btnPlay.setAttribute("aria-label", video.paused ? "Play trailer" : "Pause trailer");
      }
    }

    function tryPlay() {
      var p = video.play();
      if (p && typeof p.catch === "function") {
        p.catch(function () { syncUI(); });
      }
    }

    if (reduceMotion) { video.removeAttribute("autoplay"); video.pause(); }

    if (btnSound) btnSound.addEventListener("click", function () {
      video.muted = !video.muted;
      if (!video.muted && video.paused) tryPlay();
      syncUI();
    });

    if (btnPlay) btnPlay.addEventListener("click", function () {
      if (video.paused) tryPlay(); else video.pause();
    });

    // "Watch the trailer" — restart with sound and clear the overlay
    btnWatch.forEach(function (b) {
      b.addEventListener("click", function (e) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
        video.currentTime = 0;
        video.muted = false;
        video.loop = false;
        hero.classList.add("is-watching");
        tryPlay();
        syncUI();
      });
    });

    video.addEventListener("ended", function () {
      hero.classList.remove("is-watching");
      video.loop = true;
      video.muted = true;
      video.currentTime = 0;
      tryPlay();
      syncUI();
    });

    // Bring the headline back if the viewer pauses or scrolls away
    video.addEventListener("pause", function () { hero.classList.remove("is-watching"); syncUI(); });
    video.addEventListener("play", syncUI);
    video.addEventListener("volumechange", syncUI);
    video.addEventListener("timeupdate", function () {
      if (bar && video.duration) bar.style.width = (video.currentTime / video.duration * 100) + "%";
    });

    // Pause when hero is fully off-screen to save battery/bandwidth
    if ("IntersectionObserver" in window) {
      var wasPlaying = false;
      new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) {
            wasPlaying = !video.paused;
            if (wasPlaying) video.pause();
          } else if (wasPlaying && !reduceMotion) {
            tryPlay();
          }
        });
      }, { threshold: 0 }).observe(hero);
    }

    syncUI();
  }

  /* ---------- Ember particles (decorative) ---------- */
  document.querySelectorAll("canvas.embers").forEach(function (canvas) {
    if (reduceMotion || !canvas.getContext) return;
    var ctx = canvas.getContext("2d");
    var parts = [];
    var w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
    var running = false, raf = null;

    function resize() {
      var r = canvas.getBoundingClientRect();
      w = r.width; h = r.height;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var count = Math.round(Math.min(70, w / 18));
      parts = [];
      for (var i = 0; i < count; i++) parts.push(spawn(true));
    }
    function spawn(initial) {
      return {
        x: Math.random() * w,
        y: initial ? Math.random() * h : h + 10,
        r: Math.random() * 1.8 + 0.4,
        vy: Math.random() * 0.45 + 0.15,
        vx: (Math.random() - 0.5) * 0.25,
        a: Math.random() * 0.6 + 0.2,
        t: Math.random() * Math.PI * 2
      };
    }
    function tick() {
      ctx.clearRect(0, 0, w, h);
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        p.t += 0.02; p.y -= p.vy; p.x += p.vx + Math.sin(p.t) * 0.2;
        if (p.y < -10) parts[i] = p = spawn(false);
        var alpha = p.a * (0.6 + Math.sin(p.t * 2) * 0.4);
        ctx.beginPath();
        ctx.fillStyle = "rgba(243,196,110," + alpha.toFixed(3) + ")";
        ctx.shadowColor = "rgba(243,196,110,0.9)";
        ctx.shadowBlur = 8;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    }
    resize();
    window.addEventListener("resize", resize);
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting && !running) { running = true; tick(); }
          else if (!entry.isIntersecting && running) { running = false; cancelAnimationFrame(raf); }
        });
      }).observe(canvas);
    } else { tick(); }
  });

  /* ---------- Contact form ---------- */
  var form = document.getElementById("contactForm");
  if (form) {
    var status = document.getElementById("formStatus");
    var rules = {
      name: function (v) { return v.trim().length >= 2 || "Please enter your name."; },
      email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || "Please enter a valid email address."; },
      topic: function (v) { return v !== "" || "Please choose a topic."; },
      message: function (v) { return v.trim().length >= 10 || "Your message should be at least 10 characters."; }
    };

    function validateField(input) {
      var rule = rules[input.name];
      if (!rule) return true;
      var result = rule(input.value);
      var field = input.closest(".field");
      var err = field && field.querySelector(".field-error");
      if (result === true) {
        field && field.classList.remove("has-error");
        input.removeAttribute("aria-invalid");
        if (err) err.textContent = "";
        return true;
      }
      field && field.classList.add("has-error");
      input.setAttribute("aria-invalid", "true");
      if (err) err.textContent = result;
      return false;
    }

    Object.keys(rules).forEach(function (name) {
      var input = form.elements[name];
      if (!input) return;
      input.addEventListener("blur", function () { validateField(input); });
      input.addEventListener("input", function () {
        if (input.closest(".field").classList.contains("has-error")) validateField(input);
      });
    });

    function showStatus(msg, isError) {
      status.textContent = msg;
      status.classList.add("is-visible");
      status.classList.toggle("is-error", !!isError);
      status.focus();
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = true, firstBad = null;
      Object.keys(rules).forEach(function (name) {
        var input = form.elements[name];
        if (input && !validateField(input)) { ok = false; firstBad = firstBad || input; }
      });
      if (!ok) { firstBad.focus(); return; }
      if (form.elements.company && form.elements.company.value) return; // honeypot

      var action = form.getAttribute("action") || "";
      var submitBtn = form.querySelector("button[type=submit]");
      var label = submitBtn.querySelector("span");
      var original = label.textContent;

      // No form endpoint configured yet: open the visitor's email app instead.
      if (!action || action.indexOf("YOUR_FORM_ID") !== -1) {
        var to = form.getAttribute("data-mailto") || "";
        var subject = "[Website] " + form.elements.topic.value + " — " + form.elements.name.value.trim();
        var body = form.elements.message.value.trim() + "\n\n— " + form.elements.name.value.trim() + " (" + form.elements.email.value.trim() + ")";
        window.location.href = "mailto:" + to + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
        showStatus("Your email app should now open with the message ready to send. Thank you for reaching out.");
        return;
      }

      submitBtn.disabled = true;
      label.textContent = "Sending…";
      fetch(action, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } })
        .then(function (res) {
          if (!res.ok) throw new Error("Request failed");
          form.reset();
          showStatus("Thank you — your message has been received. Gary's team will be in touch soon.");
        })
        .catch(function () {
          showStatus("Something went wrong sending your message. Please try again in a moment.", true);
        })
        .then(function () { submitBtn.disabled = false; label.textContent = original; });
    });
  }

  /* ---------- Footer year ---------- */
  document.querySelectorAll("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
})();
