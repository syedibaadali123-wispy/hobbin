# Gary J. Hobbins — Author Website

A static, dependency-free website for author Gary J. Hobbins and *The Mind's New Liberation*.

## Pages
| File | Page |
|---|---|
| `index.html` | Home with the trailer playing live in the hero |
| `about.html` | About the author: story, journey timeline, beliefs |
| `books.html` | The book: synopsis, contents, Lesson Plan Directive, full trailer player |
| `contact.html` | Contact form + FAQ |

A floating **Buy the Book** tab (right edge on desktop, bottom bar on phones) links to Amazon on every page.

## Structure
```
assets/
  css/style.css      all styles (responsive, reduced-motion aware)
  js/main.js         nav, scroll reveals, hero video controls, ember particles, form validation
  video/trailer.mp4  web-optimized trailer (H.264/AAC, 1080p, fast-start)
  img/               book cover (600px + 1200px, JPG + WebP), social share image, trailer stills, favicon
```

## Book cover
The cover appears as a 3D book mockup (Home, Books, and the "Available now" section), as a card in the hero, and on the Contact page.
To swap in a new or higher-resolution cover, replace these files and keep the names and the 600 x 919 (2:3) proportion:
`assets/img/book-cover.jpg`, `book-cover.webp` (1200 px wide) and `book-cover-600.jpg`, `book-cover-600.webp` (600 px wide).

## Run locally
Open `index.html` in a browser, or serve the folder for the best results:
```
python3 -m http.server 8000   # then visit http://localhost:8000
```

## Deploy
Upload the whole folder to any static host (Netlify, Vercel, GitHub Pages, cPanel, etc.). No build step is needed.

## Hero trailer behaviour
- Browsers only allow autoplay when muted, so the trailer starts muted and loops.
- **Sound on/off** and **play/pause** buttons sit at the bottom-left of the hero.
- **Watch with sound** restarts the trailer from the beginning with audio and fades the headline out. The headline returns when the trailer is paused or ends.
- The video pauses automatically when scrolled off-screen.

## Contact form: one setup step
The form validates input but needs somewhere to send messages. Choose one option:
1. **Formspree (recommended):** create a free form at formspree.io, then in `contact.html` replace `YOUR_FORM_ID` in the form's `action` attribute with the form ID.
2. **Email fallback:** set `data-mailto="you@example.com"` on the `<form>` tag. Until an endpoint is configured, submitting opens the visitor's email app with the message pre-filled.

## Editing content
- Amazon link: search for `B0HKQ6V7LP` and replace it in all four HTML files.
- Colours and fonts are CSS variables at the top of `assets/css/style.css`.
- Fonts load from Google Fonts (Cormorant Garamond + Jost).
